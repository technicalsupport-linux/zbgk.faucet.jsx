use crate::accounts_ix::*;
use anchor_lang::prelude::*;

#[allow(clippy::too_many_arguments)]
pub fn perp_close_market(_ctx: Context<PerpCloseMarket>) -> Result<()> {
    Ok(())
}
