use crate::accounts_ix::*;
use anchor_lang::prelude::*;

pub fn serum3_deregister_market(_ctx: Context<Serum3DeregisterMarket>) -> Result<()> {
    Ok(())
}
