
declare const FAUCET_CLIENT_VERSION: string;
declare const FAUCET_CLIENT_BUILDTIME: number;
