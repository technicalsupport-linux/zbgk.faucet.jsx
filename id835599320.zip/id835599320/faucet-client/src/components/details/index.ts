
export * from './DetailsPage'
