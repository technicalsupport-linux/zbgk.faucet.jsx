

export * as claim from './claim'
export * as details from './details'
export * as frontpage from './frontpage'
export * as mining from './mining'
export * as passport from './passport'
export * as shared from './shared'
export * as status from './status'

export * from './FaucetPage'
