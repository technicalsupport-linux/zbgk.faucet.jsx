import 'mocha';
import sinon from 'sinon';
import { expect } from 'chai';
import { bindTestStubs, unbindTestStubs, loadDefaultTestConfig, awaitSleepPromise } from '../common.js';
import { ServiceManager } from '../../src/common/ServiceManager.js';
import { FaucetDatabase } from '../../src/db/FaucetDatabase.js';
import { ModuleManager } from '../../src/modules/ModuleManager.js';
import { SessionManager } from '../../src/session/SessionManager.js';
import { faucetConfig } from '../../src/config/FaucetConfig.js';
import { IPoWConfig, PoWHashAlgo } from '../../src/modules/pow/PoWConfig.js';
import { FaucetWebApi } from '../../src/webserv/FaucetWebApi.js';
import { disposeFakeWebSockets, FakeWebSocket, injectFakeWebSocket } from '../stubs/FakeWebSocket.js';
import { PoWModule } from '../../src/modules/pow/PoWModule.js';


describe("Faucet module: pow", () => {
  let globalStubs;

  beforeEach(async () => {
    globalStubs = bindTestStubs();
    loadDefaultTestConfig();
    await ServiceManager.GetService(FaucetDatabase).initialize();
  });
  afterEach(async () => {
    let dbService = ServiceManager.GetService(FaucetDatabase);
    await ServiceManager.DisposeAllServices();
    await dbService.closeDatabase();
    await unbindTestStubs(globalStubs);
    disposeFakeWebSockets();
  });

  it("Check client config exports (scrypt)", async () => {
    faucetConfig.modules["pow"] = {
      enabled: true,
      powShareReward: 10,
      powSessionTimeout: 60,
      powHashAlgo: PoWHashAlgo.SCRYPT,
      powScryptParams: {
        cpuAndMemory: 4096,
        blockSize: 8,
        parallelization: 1,
        keyLength: 16,
      },
      powDifficulty: 11,
      powHashrateSoftLimit: 1337,
    } as IPoWConfig;
    let moduleManager = ServiceManager.GetService(ModuleManager);
    await moduleManager.initialize();
    let clientConfig = ServiceManager.GetService(FaucetWebApi).onGetFaucetConfig();
    expect(!!clientConfig.modules['pow']).to.equal(true, "no pow config exported");
    expect(clientConfig.modules['pow'].powTimeout).to.equal(60, "client config mismatch: powTimeout");
    expect(clientConfig.modules['pow'].powParams.a).to.equal(PoWHashAlgo.SCRYPT, "client config mismatch: powParams.a");
    expect(clientConfig.modules['pow'].powParams.n).to.equal(4096, "client config mismatch: powParams.n");
    expect(clientConfig.modules['pow'].powParams.r).to.equal(8, "client config mismatch: powParams.r");
    expect(clientConfig.modules['pow'].powParams.p).to.equal(1, "client config mismatch: powParams.p");
    expect(clientConfig.modules['pow'].powParams.l).to.equal(16, "client config mismatch: powParams.l");
    expect(clientConfig.modules['pow'].powDifficulty).to.equal(11, "client config mismatch: powDifficulty");
    expect(clientConfig.modules['pow'].powHashrateLimit).to.equal(1337, "client config mismatch: powHashrateLimit");
  });

  it("Check client config exports (cryptonight)", async () => {
    faucetConfig.modules["pow"] = {
      enabled: true,
      powShareReward: 10,
      powSessionTimeout: 60,
      powHashAlgo: PoWHashAlgo.CRYPTONIGHT,
      powCryptoNightParams: {
        algo: 0,
        variant: 1,
        height: 10,
      },
      powDifficulty: 11,
      powHashrateSoftLimit: 1337,
    } as IPoWConfig;
    let moduleManager = ServiceManager.GetService(ModuleManager);
    await moduleManager.initialize();
    let clientConfig = ServiceManager.GetService(FaucetWebApi).onGetFaucetConfig();
    expect(!!clientConfig.modules['pow']).to.equal(true, "no pow config exported");
    expect(clientConfig.modules['pow'].powTimeout).to.equal(60, "client config mismatch: powTimeout");
    expect(clientConfig.modules['pow'].powParams.a).to.equal(PoWHashAlgo.CRYPTONIGHT, "client config mismatch: powParams.a");
    expect(clientConfig.modules['pow'].powParams.c).to.equal(0, "client config mismatch: powParams.c");
    expect(clientConfig.modules['pow'].powParams.v).to.equal(1, "client config mismatch: powParams.v");
    expect(clientConfig.modules['pow'].powParams.h).to.equal(10, "client config mismatch: powParams.h");
    expect(clientConfig.modules['pow'].powDifficulty).to.equal(11, "client config mismatch: powDifficulty");
    expect(clientConfig.modules['pow'].powHashrateLimit).to.equal(1337, "client config mismatch: powHashrateLimit");
  });

  it("Check client config exports (argon2)", async () => {
    faucetConfig.modules["pow"] = {
      enabled: true,
      powShareReward: 10,
      powSessionTimeout: 60,
      powHashAlgo: PoWHashAlgo.ARGON2,
      powArgon2Params: {
        type: 0,
        version: 13,
        timeCost: 4,
        memoryCost: 4096,
        parallelization: 1,
        keyLength: 16,
      },
      powDifficulty: 11,
      powHashrateSoftLimit: 1337,
    } as IPoWConfig;
    let moduleManager = ServiceManager.GetService(ModuleManager);
    await moduleManager.initialize();
    let clientConfig = ServiceManager.GetService(FaucetWebApi).onGetFaucetConfig();
    expect(!!clientConfig.modules['pow']).to.equal(true, "no pow config exported");
    expect(clientConfig.modules['pow'].powTimeout).to.equal(60, "client config mismatch: powTimeout");
    expect(clientConfig.modules['pow'].powParams.a).to.equal(PoWHashAlgo.ARGON2, "client config mismatch: powParams.a");
    expect(clientConfig.modules['pow'].powParams.t).to.equal(0, "client config mismatch: powParams.t");
    expect(clientConfig.modules['pow'].powParams.v).to.equal(13, "client config mismatch: powParams.v");
    expect(clientConfig.modules['pow'].powParams.i).to.equal(4, "client config mismatch: powParams.i");
    expect(clientConfig.modules['pow'].powParams.m).to.equal(4096, "client config mismatch: powParams.m");
    expect(clientConfig.modules['pow'].powParams.p).to.equal(1, "client config mismatch: powParams.p");
    expect(clientConfig.modules['pow'].powParams.l).to.equal(16, "client config mismatch: powParams.l");
    expect(clientConfig.modules['pow'].powDifficulty).to.equal(11, "client config mismatch: powDifficulty");
    expect(clientConfig.modules['pow'].powHashrateLimit).to.equal(1337, "client config mismatch: powHashrateLimit");
  });

  it("Start mining session and check session params", async () => {
    faucetConfig.modules["pow"] = {
      enabled: true,
    } as IPoWConfig;
    let moduleManager = ServiceManager.GetService(ModuleManager);
    await moduleManager.initialize();
    let sessionManager = ServiceManager.GetService(SessionManager);
    let testSession = await sessionManager.createSession("::ffff:8.8.8.8", {
      addr: "0x0000000000000000000000000000000000001337",
    });
    expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
    let clientInfo = await testSession.getSessionInfo();
    expect(!!(clientInfo.modules as any)["pow"]).to.equal(true, "missing pow info in client session info");
    expect((clientInfo.modules as any)["pow"].lastNonce).to.equal(0, "invalid pow info in client session info: lastNonce");
    expect((clientInfo.modules as any)["pow"].preImage).to.equal(testSession.getSessionData("pow.preimage"), "invalid pow info in client session info: preImage");
    expect((clientInfo.modules as any)["pow"].shareCount).to.equal(0, "invalid pow info in client session info: shareCount");
  });

  it("Start mining session and connect mining client", async () => {
    faucetConfig.modules["pow"] = {
      enabled: true,
    } as IPoWConfig;
    let moduleManager = ServiceManager.GetService(ModuleManager);
    await moduleManager.initialize();
    let sessionManager = ServiceManager.GetService(SessionManager);
    let testSession = await sessionManager.createSession("::ffff:8.8.8.8", {
      addr: "0x0000000000000000000000000000000000001337",
    });
    expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
    let fakeWs = await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
    expect(fakeWs.isReady).to.equal(true, "websocket was closed");
    let errorMsg = fakeWs.getSentMessage("error");
    expect(errorMsg.length).to.equal(0, "a unexpected error message has been sent: " + (errorMsg.length ? errorMsg[0].data.code : ""));
  });

  it("Connect invalid mining client (missing session id)", async () => {
    faucetConfig.modules["pow"] = {
      enabled: true,
    } as IPoWConfig;
    let moduleManager = ServiceManager.GetService(ModuleManager);
    await moduleManager.initialize();
    let fakeWs = await injectFakeWebSocket("/ws/pow", "8.8.8.8");
    expect(fakeWs.isReady).to.equal(false, "websocket not closed");
    let errorMsg = fakeWs.getSentMessage("error");
    expect(errorMsg.length).to.equal(1, "no error message sent");
    expect(errorMsg[0].data.code).to.equal("INVALID_SESSION", "unexpected error code");
  });

  it("Connect invalid mining client (unknown session id)", async () => {
    faucetConfig.modules["pow"] = {
      enabled: true,
    } as IPoWConfig;
    let moduleManager = ServiceManager.GetService(ModuleManager);
    await moduleManager.initialize();
    let fakeWs = await injectFakeWebSocket("/ws/pow?session=e36ec5e6-12ee-4015-951f-b018b37de451", "8.8.8.8");
    expect(fakeWs.isReady).to.equal(false, "websocket not closed");
    let errorMsg = fakeWs.getSentMessage("error");
    expect(errorMsg.length).to.equal(1, "no error message sent");
    expect(errorMsg[0].data.code).to.equal("INVALID_SESSION", "unexpected error code");
  });

  it("Connect multiple mining clients for same session", async () => {
    faucetConfig.modules["pow"] = {
      enabled: true,
    } as IPoWConfig;
    let moduleManager = ServiceManager.GetService(ModuleManager);
    await moduleManager.initialize();
    let testSession = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
      addr: "0x0000000000000000000000000000000000001337",
    });
    expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
    let fakeWs = await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
    await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
    expect(fakeWs.isReady).to.equal(false, "websocket not closed");
    let errorMsg = fakeWs.getSentMessage("error");
    expect(errorMsg.length).to.equal(1, "no error message sent");
    expect(errorMsg[0].data.code).to.equal("CLIENT_KILLED", "unexpected error code");
  });

  describe("Mining websocket protocol", () => {

    it("check ping timeout handling", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
        powPingInterval: 1,
        powPingTimeout: 2,
      } as IPoWConfig;
      globalStubs["FakeWebSocket.ping"] = sinon.stub(FakeWebSocket.prototype, "ping");
      globalStubs["FakeWebSocket.pong"] = sinon.stub(FakeWebSocket.prototype, "pong");
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      });
      expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
      let fakeSocket = await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
      fakeSocket.emit("pong");
      fakeSocket.emit("ping");
      expect(globalStubs["FakeWebSocket.pong"].called).to.equal(true, "pong not called");
      expect(globalStubs["FakeWebSocket.ping"].called).to.equal(false, "unexpected ping call");
      await awaitSleepPromise(1100, () => globalStubs["FakeWebSocket.ping"].called);
      expect(fakeSocket.isReady).to.equal(true, "client not ready");
      expect(globalStubs["FakeWebSocket.ping"].called).to.equal(true, "ping not called");
      expect(fakeSocket.isReady).to.equal(true, "unexpected close call");
      await awaitSleepPromise(3000, () => !fakeSocket.isReady);
      expect(fakeSocket.isReady).to.equal(false, "client is still ready");
    }).timeout(5000);

    it("check invalid message handling", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
      } as IPoWConfig;
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      });
      expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
      let fakeSocket = await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
      fakeSocket.emit("message", "invalid stuff (not json)");
      //expect(fakeSocket.isReady).to.equal(false, "client is still ready");
      let errorMsg = fakeSocket.getSentMessage("error");
      expect(errorMsg.length).to.equal(1, "no error message sent");
      expect(errorMsg[0].data.code).to.equal("CLIENT_KILLED", "unexpected error code");
    });

    it("check unknown action handling", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
      } as IPoWConfig;
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      });
      expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
      let fakeSocket = await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
      fakeSocket.emit("message", JSON.stringify({
        id: 42,
        action: "unknownAction"
      }))
      expect(fakeSocket.isReady).to.equal(true, "client is not ready");
      let errorMsg = fakeSocket.getSentMessage("error");
      expect(errorMsg.length).to.equal(1, "no error message sent");
      expect(errorMsg[0].rsp).to.equal(42, "invalid response id");
      expect(errorMsg[0].data.code).to.equal("INVALID_ACTION", "unexpected error code");
    });

    it("check action 'foundShare': invalid share data", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
      } as IPoWConfig;
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      });
      expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
      let fakeSocket = await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
      fakeSocket.emit("message", JSON.stringify({
        id: 42,
        action: "foundShare",
      }))
      expect(fakeSocket.isReady).to.equal(true, "client is not ready");
      let errorMsg = fakeSocket.getSentMessage("error");
      expect(errorMsg.length).to.equal(1, "no error message sent");
      expect(errorMsg[0].rsp).to.equal(42, "invalid response id");
      expect(errorMsg[0].data.code).to.equal("INVALID_SHARE", "unexpected error code");
      expect(errorMsg[0].data.message).to.equal("Invalid share data", "unexpected error message");
    });

    it("check action 'foundShare': invalid share params", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
        powHashAlgo: PoWHashAlgo.SCRYPT,
        powScryptParams: {
          cpuAndMemory: 4096,
          blockSize: 8,
          parallelization: 1,
          keyLength: 16,
        },
        powDifficulty: 11,
      } as IPoWConfig;
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      });
      expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
      let fakeSocket = await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
      fakeSocket.emit("message", JSON.stringify({
        id: 42,
        action: "foundShare",
        data: {
          nonce: 1337,
          params: "invalid_params_str",
          hashrate: 12,
        }
      }))
      expect(fakeSocket.isReady).to.equal(true, "client is not ready");
      let errorMsg = fakeSocket.getSentMessage("error");
      expect(errorMsg.length).to.equal(1, "no error message sent");
      expect(errorMsg[0].rsp).to.equal(42, "invalid response id");
      expect(errorMsg[0].data.code).to.equal("INVALID_SHARE", "unexpected error code");
      expect(errorMsg[0].data.message).to.equal("Invalid share params", "unexpected error message");
    });

    it("check action 'foundShare': nonce too low", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
        powHashAlgo: PoWHashAlgo.SCRYPT,
        powScryptParams: {
          cpuAndMemory: 4096,
          blockSize: 8,
          parallelization: 1,
          keyLength: 16,
        },
        powDifficulty: 11,
      } as IPoWConfig;
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      }, {
        "pow.lastNonce": 1337,
      });
      expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
      let fakeSocket = await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
      fakeSocket.emit("message", JSON.stringify({
        id: 42,
        action: "foundShare",
        data: {
          nonce: 1337,
          params: "scrypt|4096|8|1|16|11",
          hashrate: 12,
        }
      }))
      expect(fakeSocket.isReady).to.equal(true, "client is not ready");
      let errorMsg = fakeSocket.getSentMessage("error");
      expect(errorMsg.length).to.equal(1, "no error message sent");
      expect(errorMsg[0].rsp).to.equal(42, "invalid response id");
      expect(errorMsg[0].data.code).to.equal("INVALID_SHARE", "unexpected error code");
      expect(errorMsg[0].data.message).to.matches(/Nonce too low/i, "unexpected error message");
    });

    it("check action 'foundShare': nonce too high", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
        powHashAlgo: PoWHashAlgo.SCRYPT,
        powScryptParams: {
          cpuAndMemory: 4096,
          blockSize: 8,
          parallelization: 1,
          keyLength: 16,
        },
        powDifficulty: 11,
        powHashrateHardLimit: 100,
      } as IPoWConfig;
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      });
      expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
      let fakeSocket = await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
      fakeSocket.emit("message", JSON.stringify({
        id: 42,
        action: "foundShare",
        data: {
          nonce: 133700,
          params: "scrypt|4096|8|1|16|11",
          hashrate: 12,
        }
      }))
      expect(fakeSocket.isReady).to.equal(true, "client is not ready");
      let errorMsg = fakeSocket.getSentMessage("error");
      expect(errorMsg.length).to.equal(1, "no error message sent");
      expect(errorMsg[0].rsp).to.equal(42, "invalid response id");
      expect(errorMsg[0].data.code).to.equal("HASHRATE_LIMIT", "unexpected error code");
      expect(errorMsg[0].data.message).to.matches(/Nonce too high/i, "unexpected error message");
    });

    it("check action 'foundShare': valid share, local verification, scrypt", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
        powShareReward: 10,
        powHashAlgo: PoWHashAlgo.SCRYPT,
        powScryptParams: {
          cpuAndMemory: 4096,
          blockSize: 8,
          parallelization: 1,
          keyLength: 16,
        },
        powDifficulty: 11,
        powHashrateHardLimit: 100,
        verifyLocalLowPeerPercent: 100,
      } as IPoWConfig;
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      }, {
        "pow.preimage": "oXwNMIuRUOc=",
      });
      expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
      let fakeSocket = await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
      fakeSocket.emit("message", JSON.stringify({
        id: 42,
        action: "foundShare",
        data: {
          nonce: 1524,
          params: "scrypt|4096|8|1|16|11",
          hashrate: 12,
        }
      }))
      expect(fakeSocket.isReady).to.equal(true, "client is not ready");
      await awaitSleepPromise(1000, () => fakeSocket.getSentMessage("ok").length > 0);
      let okMsg = fakeSocket.getSentMessage("ok");
      expect(okMsg.length).to.equal(1, "no ok message sent");
      expect(okMsg[0].rsp).to.equal(42, "invalid response id");
      await awaitSleepPromise(100, () => fakeSocket.getSentMessage("updateBalance").length > 0);
      let balanceMsg = fakeSocket.getSentMessage("updateBalance");
      expect(balanceMsg.length).to.equal(1, "no updateBalance message sent");
      expect(balanceMsg[0].data.balance).to.equal("10", "invalid updateBalance message: unexpected balance");
      expect(balanceMsg[0].data.reason).to.matches(/valid share/, "invalid updateBalance message: unexpected reason");
    });

    it("check action 'foundShare': invalid share, local verification, scrypt", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
        powHashAlgo: PoWHashAlgo.SCRYPT,
        powScryptParams: {
          cpuAndMemory: 4096,
          blockSize: 8,
          parallelization: 1,
          keyLength: 16,
        },
        powDifficulty: 11,
        powHashrateHardLimit: 100,
        verifyLocalLowPeerPercent: 100,
      } as IPoWConfig;
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      }, {
        "pow.preimage": "oXwNMIuRUOc=",
      });
      expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
      let fakeSocket = await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
      fakeSocket.emit("message", JSON.stringify({
        id: 42,
        action: "foundShare",
        data: {
          nonce: 1526,
          params: "scrypt|4096|8|1|16|11",
          hashrate: 12,
        }
      }))
      expect(fakeSocket.isReady).to.equal(true, "client is not ready");
      await awaitSleepPromise(1000, () => !fakeSocket.isReady);
      let errorMsg = fakeSocket.getSentMessage("error");
      expect(errorMsg.length).to.equal(2, "unexpected number of error messages sent");
      expect(errorMsg[0].rsp).to.equal(42, "invalid response id");
      expect(errorMsg[0].data.code).to.equal("WRONG_SHARE", "unexpected error1 code");
      expect(errorMsg[0].data.message).to.matches(/verification failed/i, "unexpected error1 message");
      expect(errorMsg[1].data.code).to.equal("CLIENT_KILLED", "unexpected error2 code");
      expect(errorMsg[1].data.message).to.matches(/session failed/i, "unexpected error2 message");
      expect(testSession.getDropAmount()).to.equal(0n, "unexpected drop amount");
    });

    it("check action 'foundShare': valid share, local verification, cryptonight", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
        powShareReward: 10,
        powHashAlgo: PoWHashAlgo.CRYPTONIGHT,
        powCryptoNightParams: {
          algo: 0,
          variant: 0,
          height: 0,
        },
        powDifficulty: 11,
        powHashrateHardLimit: 100,
        verifyLocalLowPeerPercent: 100,
      } as IPoWConfig;
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      }, {
        "pow.preimage": "2TobvsN38W8=",
      });
      expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
      let fakeSocket = await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
      fakeSocket.emit("message", JSON.stringify({
        id: 42,
        action: "foundShare",
        data: {
          nonce: 1944,
          params: "cryptonight|0|0|0|11",
          hashrate: 12,
        }
      }))
      expect(fakeSocket.isReady).to.equal(true, "client is not ready");
      await awaitSleepPromise(1000, () => fakeSocket.getSentMessage("ok").length > 0);
      let okMsg = fakeSocket.getSentMessage("ok");
      expect(okMsg.length).to.equal(1, "no ok message sent");
      expect(okMsg[0].rsp).to.equal(42, "invalid response id");
      await awaitSleepPromise(100, () => fakeSocket.getSentMessage("updateBalance").length > 0);
      let balanceMsg = fakeSocket.getSentMessage("updateBalance");
      expect(balanceMsg.length).to.equal(1, "no updateBalance message sent");
      expect(balanceMsg[0].data.balance).to.equal("10", "invalid updateBalance message: unexpected balance");
      expect(balanceMsg[0].data.reason).to.matches(/valid share/, "invalid updateBalance message: unexpected reason");
    });

    it("check action 'foundShare': invalid share, local verification, cryptonight", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
        powHashAlgo: PoWHashAlgo.CRYPTONIGHT,
        powCryptoNightParams: {
          algo: 0,
          variant: 0,
          height: 0,
        },
        powDifficulty: 11,
        powHashrateHardLimit: 100,
        verifyLocalLowPeerPercent: 100,
      } as IPoWConfig;
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      }, {
        "pow.preimage": "oXwNMIuRUOc=",
      });
      expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
      let fakeSocket = await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
      fakeSocket.emit("message", JSON.stringify({
        id: 42,
        action: "foundShare",
        data: {
          nonce: 1526,
          params: "cryptonight|0|0|0|11",
          hashrate: 12,
        }
      }))
      expect(fakeSocket.isReady).to.equal(true, "client is not ready");
      await awaitSleepPromise(1000, () => !fakeSocket.isReady);
      let errorMsg = fakeSocket.getSentMessage("error");
      expect(errorMsg.length).to.equal(2, "unexpected number of error messages sent");
      expect(errorMsg[0].rsp).to.equal(42, "invalid response id");
      expect(errorMsg[0].data.code).to.equal("WRONG_SHARE", "unexpected error1 code");
      expect(errorMsg[0].data.message).to.matches(/verification failed/i, "unexpected error1 message");
      expect(errorMsg[1].data.code).to.equal("CLIENT_KILLED", "unexpected error2 code");
      expect(errorMsg[1].data.message).to.matches(/session failed/i, "unexpected error2 message");
      expect(testSession.getDropAmount()).to.equal(0n, "unexpected drop amount");
    });

    it("check action 'foundShare': valid share, local verification, argon2", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
        powShareReward: 10,
        powHashAlgo: PoWHashAlgo.ARGON2,
        powArgon2Params: {
          type: 0,
          version: 13,
          timeCost: 4,
          memoryCost: 4096,
          parallelization: 1,
          keyLength: 16,
        },
        powDifficulty: 11,
        powHashrateHardLimit: 100,
        verifyLocalLowPeerPercent: 100,
      } as IPoWConfig;
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      }, {
        "pow.preimage": "2TobvsN38W8=",
      });
      expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
      let fakeSocket = await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
      fakeSocket.emit("message", JSON.stringify({
        id: 42,
        action: "foundShare",
        data: {
          nonce: 2034,
          params: "argon2|0|13|4|4096|1|16|11",
          hashrate: 12,
        }
      }))
      expect(fakeSocket.isReady).to.equal(true, "client is not ready");
      await awaitSleepPromise(1000, () => fakeSocket.getSentMessage("ok").length > 0);
      let okMsg = fakeSocket.getSentMessage("ok");
      expect(okMsg.length).to.equal(1, "no ok message sent");
      expect(okMsg[0].rsp).to.equal(42, "invalid response id");
      await awaitSleepPromise(100, () => fakeSocket.getSentMessage("updateBalance").length > 0);
      let balanceMsg = fakeSocket.getSentMessage("updateBalance");
      expect(balanceMsg.length).to.equal(1, "no updateBalance message sent");
      expect(balanceMsg[0].data.balance).to.equal("10", "invalid updateBalance message: unexpected balance");
      expect(balanceMsg[0].data.reason).to.matches(/valid share/, "invalid updateBalance message: unexpected reason");
    });

    it("check action 'foundShare': invalid share, local verification, argon2", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
        powHashAlgo: PoWHashAlgo.ARGON2,
        powArgon2Params: {
          type: 0,
          version: 13,
          timeCost: 4,
          memoryCost: 4096,
          parallelization: 1,
          keyLength: 16,
        },
        powDifficulty: 11,
        powHashrateHardLimit: 100,
        verifyLocalLowPeerPercent: 100,
      } as IPoWConfig;
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      }, {
        "pow.preimage": "oXwNMIuRUOc=",
      });
      expect(testSession.getSessionStatus()).to.equal("running", "unexpected session status");
      let fakeSocket = await injectFakeWebSocket("/ws/pow?session=" + testSession.getSessionId(), "8.8.8.8");
      fakeSocket.emit("message", JSON.stringify({
        id: 42,
        action: "foundShare",
        data: {
          nonce: 1526,
          params: "argon2|0|13|4|4096|1|16|11",
          hashrate: 12,
        }
      }))
      expect(fakeSocket.isReady).to.equal(true, "client is not ready");
      await awaitSleepPromise(1000, () => !fakeSocket.isReady);
      let errorMsg = fakeSocket.getSentMessage("error");
      expect(errorMsg.length).to.equal(2, "unexpected number of error messages sent");
      expect(errorMsg[0].rsp).to.equal(42, "invalid response id");
      expect(errorMsg[0].data.code).to.equal("WRONG_SHARE", "unexpected error1 code");
      expect(errorMsg[0].data.message).to.matches(/verification failed/i, "unexpected error1 message");
      expect(errorMsg[1].data.code).to.equal("CLIENT_KILLED", "unexpected error2 code");
      expect(errorMsg[1].data.message).to.matches(/session failed/i, "unexpected error2 message");
      expect(testSession.getDropAmount()).to.equal(0n, "unexpected drop amount");
    });

    it("check action 'verifyResult': valid share verification", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
        powShareReward: 10,
        powHashAlgo: PoWHashAlgo.SCRYPT,
        powScryptParams: {
          cpuAndMemory: 4096,
          blockSize: 8,
          parallelization: 1,
          keyLength: 16,
        },
        powDifficulty: 11,
        powHashrateHardLimit: 100,
        verifyMinerIndividuals: 1,
        verifyMinerPeerCount: 1,
        verifyMinerPercent: 100,
        verifyMinerRewardPerc: 50,
        verifyMinerMissPenaltyPerc: 0,
      } as IPoWConfig;
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession1 = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      }, {
        "pow.preimage": "oXwNMIuRUOc=",
      });
      let fakeSocket1 = await injectFakeWebSocket("/ws/pow?session=" + testSession1.getSessionId(), "8.8.8.8");
      expect(testSession1.getSessionStatus()).to.equal("running", "unexpected session status");
      let testSession2 = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.4.4", {
        addr: "0x0000000000000000000000000000000000001338",
      });
      let fakeSocket2 = await injectFakeWebSocket("/ws/pow?session=" + testSession2.getSessionId(), "8.8.4.4");
      expect(testSession2.getSessionStatus()).to.equal("running", "unexpected session status");
      fakeSocket1.emit("message", JSON.stringify({
        id: 42,
        action: "foundShare",
        data: {
          nonce: 1524,
          params: "scrypt|4096|8|1|16|11",
          hashrate: 12,
        }
      }));
      expect(fakeSocket1.isReady).to.equal(true, "client is not ready");
      await awaitSleepPromise(500, () => fakeSocket2.getSentMessage("verify").length > 0);
      let verifyMsg = fakeSocket2.getSentMessage("verify");
      expect(verifyMsg.length).to.equal(1, "unexpected number of verify messages sent");
      expect(verifyMsg[0].data.preimage).to.equal("oXwNMIuRUOc=", "invalid verify message: preimage mismatch");
      expect(verifyMsg[0].data.nonce).to.equal(1524, "invalid verify message: nonce mismatch");
      // send verify result
      fakeSocket2.emit("message", JSON.stringify({
        id: 43,
        action: "verifyResult",
        data: {
          shareId: verifyMsg[0].data.shareId,
          isValid: true,
        }
      }));
      await awaitSleepPromise(500, () => fakeSocket2.getSentMessage("updateBalance").length > 0);
      let balanceMsg1 = fakeSocket2.getSentMessage("updateBalance");
      expect(balanceMsg1.length).to.equal(1, "no updateBalance message sent");
      expect(balanceMsg1[0].data.balance).to.equal("5", "invalid updateBalance message: unexpected balance");
      expect(balanceMsg1[0].data.reason).to.matches(/valid verification/, "invalid updateBalance message: unexpected reason");
      await awaitSleepPromise(500, () => fakeSocket1.getSentMessage("ok").length > 0);
      let okMsg2 = fakeSocket1.getSentMessage("ok");
      expect(okMsg2.length).to.equal(1, "no ok message2 sent");
      expect(okMsg2[0].rsp).to.equal(42, "invalid response id in ok msg2");
    }).retries(3);

    it("check action 'verifyResult': invalid share verification", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
        powShareReward: 10,
        powHashAlgo: PoWHashAlgo.SCRYPT,
        powScryptParams: {
          cpuAndMemory: 4096,
          blockSize: 8,
          parallelization: 1,
          keyLength: 16,
        },
        powDifficulty: 11,
        powHashrateHardLimit: 100,
        verifyMinerIndividuals: 1,
        verifyMinerPeerCount: 1,
        verifyMinerPercent: 100,
        verifyMinerRewardPerc: 50,
        verifyMinerMissPenaltyPerc: 0,
      } as IPoWConfig;
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession1 = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      }, {
        "pow.preimage": "oXwNMIuRUOc=",
      });
      let fakeSocket1 = await injectFakeWebSocket("/ws/pow?session=" + testSession1.getSessionId(), "8.8.8.8");
      expect(testSession1.getSessionStatus()).to.equal("running", "unexpected session status");
      let testSession2 = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.4.4", {
        addr: "0x0000000000000000000000000000000000001338",
      });
      let fakeSocket2 = await injectFakeWebSocket("/ws/pow?session=" + testSession2.getSessionId(), "8.8.4.4");
      expect(testSession2.getSessionStatus()).to.equal("running", "unexpected session status");
      fakeSocket1.emit("message", JSON.stringify({
        id: 42,
        action: "foundShare",
        data: {
          nonce: 1524,
          params: "scrypt|4096|8|1|16|11",
          hashrate: 12,
        }
      }));
      expect(fakeSocket1.isReady).to.equal(true, "client is not ready");
      await awaitSleepPromise(1000, () => fakeSocket2.getSentMessage("verify").length > 0);
      let verifyMsg = fakeSocket2.getSentMessage("verify");
      expect(verifyMsg.length).to.equal(1, "unexpected number of verify messages sent");
      expect(verifyMsg[0].data.preimage).to.equal("oXwNMIuRUOc=", "invalid verify message: preimage mismatch");
      expect(verifyMsg[0].data.nonce).to.equal(1524, "invalid verify message: nonce mismatch");
      // send verify result
      fakeSocket2.emit("message", JSON.stringify({
        id: 43,
        action: "verifyResult",
        data: {
          shareId: verifyMsg[0].data.shareId,
          isValid: false,
        }
      }));
      await awaitSleepPromise(1000, () => !fakeSocket2.isReady);
      let errorMsg = fakeSocket2.getSentMessage("error");
      expect(errorMsg.length).to.equal(1, "unexpected number of error messages sent");
      expect(errorMsg[0].data.code).to.equal("CLIENT_KILLED", "unexpected error2 code");
      expect(errorMsg[0].data.message).to.matches(/session failed/i, "unexpected error2 message");
      await awaitSleepPromise(500, () => fakeSocket1.getSentMessage("ok").length > 0);
      let okMsg2 = fakeSocket1.getSentMessage("ok");
      expect(okMsg2.length).to.equal(1, "no ok message sent");
      expect(okMsg2[0].rsp).to.equal(42, "invalid response id");
    }).timeout(5000).retries(3);

    it("check timed out share verification", async () => {
      faucetConfig.modules["pow"] = {
        enabled: true,
        powShareReward: 10,
        powHashAlgo: PoWHashAlgo.SCRYPT,
        powScryptParams: {
          cpuAndMemory: 4096,
          blockSize: 8,
          parallelization: 1,
          keyLength: 16,
        },
        powDifficulty: 11,
        powHashrateHardLimit: 100,
        verifyMinerIndividuals: 1,
        verifyMinerPeerCount: 1,
        verifyMinerPercent: 100,
        verifyMinerRewardPerc: 50,
        verifyMinerMissPenaltyPerc: 50,
        verifyMinerTimeout: 1,
      } as IPoWConfig;
      let moduleManager = ServiceManager.GetService(ModuleManager);
      await moduleManager.initialize();
      let testSession1 = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.8.8", {
        addr: "0x0000000000000000000000000000000000001337",
      }, {
        "pow.preimage": "oXwNMIuRUOc=",
      });
      let fakeSocket1 = await injectFakeWebSocket("/ws/pow?session=" + testSession1.getSessionId(), "8.8.8.8");
      expect(testSession1.getSessionStatus()).to.equal("running", "unexpected session status");
      let testSession2 = await ServiceManager.GetService(SessionManager).createSession("::ffff:8.8.4.4", {
        addr: "0x0000000000000000000000000000000000001338",
      }, {
        "pow.preimage": "oXwNMIuRUOc=",
      });
      let fakeSocket2 = await injectFakeWebSocket("/ws/pow?session=" + testSession2.getSessionId(), "8.8.4.4");
      expect(testSession2.getSessionStatus()).to.equal("running", "unexpected session status");
      fakeSocket2.emit("message", JSON.stringify({
        id: 43,
        action: "foundShare",
        data: {
          nonce: 1524,
          params: "scrypt|4096|8|1|16|11",
          hashrate: 12,
        }
      }));
      await awaitSleepPromise(500, () => testSession2.getDropAmount() > 0n);
      expect(testSession2.getDropAmount()).to.equal(10n, "invalid drop amount");

      fakeSocket1.emit("message", JSON.stringify({
        id: 42,
        action: "foundShare",
        data: {
          nonce: 1524,
          params: "scrypt|4096|8|1|16|11",
          hashrate: 12,
        }
      }));
      expect(fakeSocket1.isReady).to.equal(true, "client is not ready");
      await awaitSleepPromise(500, () => fakeSocket2.getSentMessage("verify").length > 0);
      let verifyMsg = fakeSocket2.getSentMessage("verify");
      expect(verifyMsg.length).to.equal(1, "unexpected number of verify messages sent");
      expect(verifyMsg[0].data.preimage).to.equal("oXwNMIuRUOc=", "invalid verify message: preimage mismatch");
      expect(verifyMsg[0].data.nonce).to.equal(1524, "invalid verify message: nonce mismatch");
      await awaitSleepPromise(1500, () => fakeSocket1.getSentMessage("ok").length > 0);
      let okMsg2 = fakeSocket1.getSentMessage("ok");
      expect(okMsg2.length).to.equal(1, "no ok message sent");
      expect(okMsg2[0].rsp).to.equal(42, "invalid response id");
      let balanceMsg = fakeSocket2.getSentMessage("updateBalance");
      expect(balanceMsg.length).to.equal(2, "no updateBalance message sent");
      expect(balanceMsg[1].data.balance).to.equal("5", "invalid updateBalance message: unexpected balance");
      expect(balanceMsg[1].data.reason).to.matches(/verify miss/, "invalid updateBalance message: unexpected reason");
    }).timeout(5000).retries(3);

  });

});