
const POWFAUCET_VERSION: string = "";
