
export interface ISessionRewardFactor {
  factor: number;
  module: string;
  name?: string;
}