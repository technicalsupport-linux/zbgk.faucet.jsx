
export interface IFaucetResultSharingConfig {
  preHtml: string;
  postHtml: string;
  caption: string;
  [provider: string]: string;
}
